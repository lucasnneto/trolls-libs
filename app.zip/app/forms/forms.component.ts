import { Component, OnInit } from '@angular/core';
import { BooksService } from '../books.service';
import { Router } from '@angular/router';
import { NbDialogService } from '@nebular/theme';
import { DialogBuscaComponent } from '../dialog-busca/dialog-busca.component';
import { IGoogleBook } from '../users.service';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.scss'],
})
export class FormsComponent implements OnInit {
  constructor(private router: Router, private bookService: BooksService, private dialogService: NbDialogService) { }
  ngOnInit(): void {
    const token = sessionStorage.getItem('token');
    if (!token) {
      this.router.navigate(['/login']);
      return;
    }
    this.token = token;
  }
  token = '';
  loading = false;
  nomeColecao = '';
  libs: { title: string; author: string }[] = [
    {
      title: '',
      author: '',
    },
  ];
  buscarDetalhes(index: number) {
    const dialogRef = this.dialogService.open(DialogBuscaComponent, {
    });
    dialogRef.onClose.subscribe((data: IGoogleBook) => {
      this.libs[index].author = data.volumeInfo.authors[0] || '';
      this.libs[index].title = data.volumeInfo.title || '';
    });
  }
  incluirLivro() {
    this.libs.push({
      title: '',
      author: '',
    });
  }
  removerLivro(index: number) {
    this.libs.splice(index, 1);
  }
  finalizarCriacao() {
    this.loading = true;
    const newBooks = this.libs.map((el) => ({
      ...el,
      series: this.nomeColecao || undefined,
    }));
    this.bookService.addNew({ books: newBooks }, this.token).subscribe({
      error: () => {
        this.loading = false;
        alert('Ocorreu um erro ao adicionar a coleção');
      },
      complete: () => {
        this.loading = false;
        alert('Coleção criada com sucesso');
        this.router.navigate(['/dashboard']);
      },
    });
  }
}

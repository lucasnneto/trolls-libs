export const environment = {
  production: false,
  apiUrl: 'https://book-api-eta-indol.vercel.app/',
};

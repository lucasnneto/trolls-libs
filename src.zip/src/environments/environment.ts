export const environment = {
  production: true,
  apiUrl: 'https://book-api-eta-indol.vercel.app/',
};
